@extends('layout.master') 
@section('title', 'home') 


@section('content')
    <div class="row" style="margin: 50px 0 150px 0">
        <div class="col-md-6 col-md-offset-3 text-center">
            <p class="headingFont">RMIT ITS SERVICE</p>
        </div>
    </div>
@endsection




